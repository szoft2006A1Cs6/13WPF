﻿using Microsoft.EntityFrameworkCore;
using Wepshop_Projekt.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wepshop_Projekt.Database
{
    class WebshopContext : DbContext
    {
        public DbSet<Kategoria> Kategoria { get; set; }
        public DbSet<Rendeles> Rendeles { get; set; }
        public DbSet<Rendelestetel> Rendelestetel { get; set; }
        public DbSet<Termek> Termek { get; set; }
        public DbSet<Vasarlo> Vasarlo { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // MySQL kapcsolódás (port, adatbázis, user, jelszó igény szerint)
            optionsBuilder.UseMySql(
                "server=localhost;port=3306;database=webshop;user=root",
                new MySqlServerVersion(new Version(8, 0, 36))
            );

        }

    }
}
