﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Wepshop_Projekt.Database;
using Wepshop_Projekt.Models;

namespace Wepshop_Projekt
{
    /// <summary>
    /// Interaction logic for OrdersWindow.xaml
    /// </summary>
    public partial class OrdersWindow : Window
    {
        public OrdersWindow()
        {
            InitializeComponent();
            using (var ctx = new WebshopContext())
            {
                lbRendeles.Items.Clear();
                var rendelesek = ctx.Rendeles
                    .Include(r => r.Vasarlo)
                    .Include(r => r.Rendelestetelek)
                        .ThenInclude(rt => rt.Termek)
                    .ToList();

                foreach (var r in rendelesek)
                    lbRendeles.Items.Add(r);
            }
        }

        private void lbRendeles_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var valasztott = lbRendeles.SelectedItem as Rendeles;
            if (valasztott == null) return;

            tbId.Text = valasztott.RendelesId.ToString();
            tbVasarlo.Text = valasztott.Vasarlo.Nev;
            tbDatum.Text = valasztott.Datum.ToString();
            tbOsszeg.Text = valasztott.Osszeg.ToString();
            if(valasztott.Rendelestetelek != null) {
                foreach (var item in valasztott.Rendelestetelek)
                {
                    tbTetelek.Text += $"{item}\n";
                }
            }
        }

        private void btnMentes_Click(object sender, RoutedEventArgs e)
        {
            using (var ctx = new WebshopContext())
            {
                int id;
                int.TryParse(tbId.Text, out id);

                var rendeles = new Rendeles
                {
                    RendelesId = id,
                    Datum = DateTime.Parse(tbDatum.Text),
                    Osszeg = int.Parse(tbOsszeg.Text)
                };

                // 1. Adatok lekérése
                var result = ctx.Rendeles
                    .FirstOrDefault(x => x.RendelesId == rendeles.RendelesId);

                // 2. Ha nincs ilyen, újként mentjük
                if (result == null)
                {
                    ctx.Rendeles.Add(rendeles);
                    ctx.SaveChanges();
                    MessageBox.Show("Új rendelés sikeresen hozzáadva!");
                    return;
                }

                // 3. Módosítás
                result.Datum = rendeles.Datum;
                result.Osszeg = rendeles.Osszeg;

                // 4. Mentés
                ctx.SaveChanges();
                MessageBox.Show("Rendelés adatai frissítve!");
            }
        }

        private void btnTorles_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbId.Text)) return;

            using (var ctx = new WebshopContext())
            {
                int id = int.Parse(tbId.Text);

                // 1. Lekérés
                var result = ctx.Rendeles.FirstOrDefault(x => x.RendelesId == id);

                // 2. Ellenőrzés
                if (result == null)
                {
                    MessageBox.Show("A rendelés nem található az adatbázisban!");
                    return;
                }

                // 3. Törlés
                ctx.Rendeles.Remove(result);
                ctx.SaveChanges();

                MessageBox.Show("A rendelés törölve!");
            }
        }
    }
}
