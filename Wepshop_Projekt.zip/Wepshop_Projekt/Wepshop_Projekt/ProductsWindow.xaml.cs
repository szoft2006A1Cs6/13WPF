﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Wepshop_Projekt.Database;
using Wepshop_Projekt.Models;

namespace Wepshop_Projekt
{
    /// <summary>
    /// Interaction logic for ProductsWindow.xaml
    /// </summary>
    public partial class ProductsWindow : Window
    {
        public ProductsWindow()
        {
            InitializeComponent();

            using (var ctx = new WebshopContext())
            {
                // Termékek betöltése a ListBox-ba (kategória névvel együtt)
                foreach (var item in ctx.Termek.Include(x => x.Kategoria))
                    lbTermek.Items.Add(item);

                // Kategóriák betöltése ComboBox-ba
                foreach (var item in ctx.Kategoria)
                    cbKategoria.Items.Add(item);
            }
        }

        private void lbTermek_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var valasztott = lbTermek.SelectedItem as Termek;
            if (valasztott == null) return;

            tbId.Text = valasztott.TermekId.ToString();
            tbNev.Text = valasztott.Nev;
            tbLeiras.Text = valasztott.Leiras;
            tbAr.Text = valasztott.Ar.ToString();
            tbKeszlet.Text = valasztott.Keszlet.ToString();
            cbKategoria.SelectedItem = valasztott.Kategoria;
        }

        private void btnMentes_Click(object sender, RoutedEventArgs e)
        {
            using (var ctx = new WebshopContext())
            {
                // 0. Adatok WPF-ből
                var kategoria = cbKategoria.SelectedItem as Kategoria;
                if (kategoria == null)
                {
                    MessageBox.Show("Kérlek, válassz kategóriát!");
                    return;
                }

                int id;
                int.TryParse(tbId.Text, out id);

                var termek = new Termek
                {
                    TermekId = id,
                    Nev = tbNev.Text,
                    Leiras = tbLeiras.Text,
                    Ar = int.Parse(tbAr.Text),
                    Keszlet = int.Parse(tbKeszlet.Text),
                    Kategoria = kategoria
                };

                // 1. Adatok lekérése
                var result = ctx.Termek
                    .Include(x => x.Kategoria)
                    .FirstOrDefault(x => x.TermekId == termek.TermekId);

                // 2. Ha nincs ilyen, újként mentjük
                if (result == null)
                {
                    MessageBox.Show("Új rendelést ilyen módon nem adhatsz hozzá.");
                    return;
                }

                // 3. Módosítás
                result.Nev = termek.Nev;
                result.Leiras = termek.Leiras;
                result.Ar = termek.Ar;
                result.Keszlet = termek.Keszlet;
                result.Kategoria.Nev = termek.Kategoria.Nev;

                // 4. Mentés
                ctx.SaveChanges();
                MessageBox.Show("Termék adatai frissítve!");
            }
        }

        private void btnTorles_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbId.Text)) return;

            using (var ctx = new WebshopContext())
            {
                int id = int.Parse(tbId.Text);

                // 1. Lekérés
                var result = ctx.Termek.FirstOrDefault(x => x.TermekId == id);

                // 2. Ellenőrzés
                if (result == null)
                {
                    MessageBox.Show("A termék nem található az adatbázisban!");
                    return;
                }

                // 3. Törlés
                ctx.Termek.Remove(result);
                ctx.SaveChanges();

                MessageBox.Show("A termék törölve!");
            }
        }
    }
}
