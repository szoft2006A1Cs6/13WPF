﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wepshop_Projekt.Models
{
    internal class Vasarlo
    {
        public int VasarloId { get; set; }
        public string? Nev { get; set; }
        public string? Email { get; set; }
        public string? Cim { get; set; }

        // Opció: a vásárlóhoz tartozó rendelések
        public List<Rendeles>? Rendelesek { get; set; }

        public override string ToString()
        {
            return $"{Nev}, {Email}";
        }
    }
}
