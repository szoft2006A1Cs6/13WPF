﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wepshop_Projekt.Models
{
    internal class Rendelestetel
    {
        public int RendelestetelId { get; set; }
        public int Mennyiseg { get; set; }

        public int RendelesId { get; set; }
        public Rendeles? Rendeles { get; set; }

        public int TermekId { get; set; }
        public Termek? Termek { get; set; }

        public override string ToString()
        {
            return $"{Termek.Nev}, {Mennyiseg}db";
        }
    }
}
