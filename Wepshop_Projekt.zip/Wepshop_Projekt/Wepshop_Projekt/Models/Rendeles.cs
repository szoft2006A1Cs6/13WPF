﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Wepshop_Projekt.Models
{
    internal class Rendeles
    {
        public int RendelesId { get; set; }
        public DateTime Datum { get; set; }
        public int Osszeg {  get; set; }

        public int VasarloId { get; set; }
        public Vasarlo? Vasarlo { get; set; }

        // Opció: a rendeléshez tartozó tételek
        public List<Rendelestetel>? Rendelestetelek { get; set; }

        public override string ToString()
        {
            return $"{Vasarlo.Nev}, {Datum}";
        }
    }
}
