﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wepshop_Projekt.Models
{
    public class Kategoria
    {
        public int KategoriaId { get; set; }
        public string? Nev { get; set; }

        // Opció: a kategóriához tartozó termékek
        public List<Termek>? Termekek { get; set; }

        public override string ToString()
        {
            return $"{Nev}";
        }
    }
}
