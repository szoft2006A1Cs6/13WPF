﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wepshop_Projekt.Models
{
    public class Termek
    {
        public int TermekId { get; set; }
        public string? Nev { get; set; }
        public string? Leiras { get; set; }
        public int Ar { get; set; }
        public int Keszlet { get; set; }

        // Kapcsolat a kategóriával
        public int KategoriaId { get; set; }
        public Kategoria? Kategoria { get; set; }

        public override string ToString()
        {
            return $"{Nev}, {Kategoria?.Nev}, {Ar} Ft";
        }
    }
}
